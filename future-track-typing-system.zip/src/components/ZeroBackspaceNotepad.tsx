import React, { useState, useEffect, useRef } from 'react';
import { 
  FileEdit, 
  AlertTriangle, 
  Download, 
  Copy, 
  Check, 
  Trash2, 
  Printer, 
  Maximize2, 
  Minimize2, 
  Clock, 
  Type, 
  Sparkles, 
  BookOpen, 
  ShieldAlert,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  Plus,
  ArrowRight,
  Layers,
  FileText,
  CheckCircle2,
  ListOrdered
} from 'lucide-react';
import { soundEngine } from '../utils/audio';
import { SoundEffectType } from '../types';

export interface ParagraphSheet {
  id: string;
  paragraphNumber: number;
  content: string;
  wordCount: number;
  charCount: number;
  backspaceCount: number;
  elapsedSeconds: number;
  promptGuidance?: string;
  isCompleted: boolean;
}

const PARAGRAPH_EXERCISE_SUITES = [
  {
    title: '3-Stage Academic Essay (Intro · Body · Conclusion)',
    category: 'Essay Structure',
    paragraphs: [
      {
        prompt: 'Paragraph 1 (Introduction & Thesis): Define the subject of digital literacy and explain why disciplined keyboarding under timed conditions is essential for contemporary students.',
        sample: 'Digital keyboarding proficiency has emerged as a cornerstone of modern educational achievement. When students master fluent touch-typing, cognitive focus shifts from mechanical key finding to analytical formulation.',
      },
      {
        prompt: 'Paragraph 2 (Body & Evidence): Detail the cognitive benefits of zero-backspace typing and how committing to keystrokes builds uninterrupted cognitive flow.',
        sample: 'Operating under zero-backspace restrictions enforces deliberate psychological discipline. Rather than hesitating and second-guessing every word, the typist develops a forward-moving cadence that improves overall throughput.',
      },
      {
        prompt: 'Paragraph 3 (Conclusion & Synthesis): Summarize key insights and conclude with actionable recommendations for sustained daily typing practice.',
        sample: 'In conclusion, continuous typing practice over ten to sixty minutes establishes durable muscle memory. Regular dedication ensures candidates meet institutional examination standards with both speed and accuracy.',
      },
    ],
  },
  {
    title: '4-Part Administrative Memorandum',
    category: 'Official Practice',
    paragraphs: [
      {
        prompt: 'Paragraph 1 (Reference & Formal Salutation): State the examination memo reference number, date, and introductory notice to candidates.',
        sample: 'MEMORANDUM REF: TRK/2026/ADM-04\nTo all prospective candidates appearing for the State Technical Keyboarding Examination: Please be advised that examination consoles require strict adherence to procedural directives.',
      },
      {
        prompt: 'Paragraph 2 (Hardware Verification): Explain keyboard connectivity, posture standards, and ergonomic verification.',
        sample: 'Candidates must ensure physical keyboard alignment before commencing the session. The home-row tactile points on the F and J keys provide the foundational reference for spatial key awareness.',
      },
      {
        prompt: 'Paragraph 3 (Integrity Protocols): Highlight zero-backspace enforcement and anti-cheating window monitor regulations.',
        sample: 'Under official regulations, retroactive keystrokes including backspace and delete are completely disabled. External clipboard interactions and window focus alterations are recorded in the central audit registry.',
      },
      {
        prompt: 'Paragraph 4 (Final Certification): State submission guidelines and qualifying score requirements.',
        sample: 'Upon countdown expiry, the evaluation engine automatically computes gross velocity and net qualifying WPM. Candidates meeting the thirty-five words-per-minute ceiling are awarded certified competency.',
      },
    ],
  },
];

export const ZeroBackspaceNotepad: React.FC = () => {
  // Mode: 'paragraph-sheets' (Always New Notepad per Paragraph) vs 'continuous'
  const [notepadMode, setNotepadMode] = useState<'paragraph-sheets' | 'continuous'>('paragraph-sheets');

  // Multi-Paragraph Sheets State
  const [paragraphSheets, setParagraphSheets] = useState<ParagraphSheet[]>(() => {
    try {
      const stored = localStorage.getItem('futuretrack_paragraph_sheets_v2');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      // fallback
    }
    return [
      {
        id: 'sheet_1',
        paragraphNumber: 1,
        content: '',
        wordCount: 0,
        charCount: 0,
        backspaceCount: 0,
        elapsedSeconds: 0,
        promptGuidance: 'Paragraph 1: Begin your initial thoughts or introductory sentences...',
        isCompleted: false,
      },
    ];
  });

  const [activeSheetIndex, setActiveSheetIndex] = useState(0);

  // Continuous single notepad content fallback
  const [continuousContent, setContinuousContent] = useState<string>(() => {
    return localStorage.getItem('futuretrack_notepad_draft') || '';
  });

  // Global Backspace attempt counter
  const [totalBackspaceAttempts, setTotalBackspaceAttempts] = useState(0);
  const [showWarning, setShowWarning] = useState(false);

  // Editor Appearance
  const [fontFamily, setFontFamily] = useState<'mono' | 'sans' | 'serif'>('mono');
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [notepadTheme, setNotepadTheme] = useState<'paper' | 'clean' | 'warm' | 'dark'>('paper');
  const [soundType, setSoundType] = useState<SoundEffectType>('mechanical');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'notepad' | 'compiled'>('notepad');

  // Timer
  const [isActiveTimer, setIsActiveTimer] = useState(false);
  const [elapsedSessionSeconds, setElapsedSessionSeconds] = useState(0);

  const timerRef = useRef<number | null>(null);
  const warningTimerRef = useRef<number | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Active Sheet reference
  const currentSheet = paragraphSheets[activeSheetIndex] || paragraphSheets[0];

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('futuretrack_paragraph_sheets_v2', JSON.stringify(paragraphSheets));
  }, [paragraphSheets]);

  useEffect(() => {
    localStorage.setItem('futuretrack_notepad_draft', continuousContent);
  }, [continuousContent]);

  // Session Stopwatch
  useEffect(() => {
    if (isActiveTimer) {
      timerRef.current = window.setInterval(() => {
        setElapsedSessionSeconds((prev) => prev + 1);
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActiveTimer]);

  // Aggregate Metrics across all paragraph sheets
  const compiledText = paragraphSheets.map((s) => s.content.trim()).filter(Boolean).join('\n\n');
  const totalWords = paragraphSheets.reduce((sum, s) => sum + s.wordCount, 0);
  const totalChars = paragraphSheets.reduce((sum, s) => sum + s.charCount, 0);
  const totalParagraphsCount = paragraphSheets.length;
  const completedParagraphsCount = paragraphSheets.filter((s) => s.isCompleted || s.wordCount > 0).length;

  const sessionMinutes = Math.max(elapsedSessionSeconds / 60, 0.0167);
  const calculatedWpm = elapsedSessionSeconds > 0 ? Math.round((totalChars / 5) / sessionMinutes) : 0;

  // Trigger warning when backspace is intercepted
  const triggerBackspaceWarning = () => {
    soundEngine.playWarning(0.65);
    setTotalBackspaceAttempts((prev) => prev + 1);
    setShowWarning(true);
    if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
    warningTimerRef.current = window.setTimeout(() => setShowWarning(false), 2400);
  };

  // Keyboard Handler (Strict Zero Backspace)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (!isActiveTimer && e.key.length === 1) {
      setIsActiveTimer(true);
    }

    // 1. Block Backspace and Delete
    if (e.key === 'Backspace' || e.key === 'Delete') {
      e.preventDefault();
      e.stopPropagation();
      triggerBackspaceWarning();
      return;
    }

    // 2. Block Cut (Ctrl+X)
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'x') {
      e.preventDefault();
      e.stopPropagation();
      triggerBackspaceWarning();
      return;
    }

    // 3. Quick shortcut to create next paragraph notepad: Ctrl + Enter
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleCreateNextParagraphNotepad();
      return;
    }

    // Audio click
    if (e.key.length === 1 || e.key === 'Enter') {
      soundEngine.playKeypress(soundType, 0.45);
    }
  };

  // Content change updater
  const handleTextChange = (value: string) => {
    if (notepadMode === 'paragraph-sheets') {
      const words = value.trim() ? value.trim().split(/\s+/).filter(Boolean) : [];
      setParagraphSheets((prev) =>
        prev.map((s, idx) =>
          idx === activeSheetIndex
            ? {
                ...s,
                content: value,
                charCount: value.length,
                wordCount: words.length,
              }
            : s
        )
      );
    } else {
      setContinuousContent(value);
    }
  };

  // Create a brand new notepad for the next paragraph
  const handleCreateNextParagraphNotepad = () => {
    // Mark current sheet as completed
    setParagraphSheets((prev) => {
      const updated = prev.map((s, idx) =>
        idx === activeSheetIndex ? { ...s, isCompleted: true } : s
      );

      const nextNum = updated.length + 1;
      const newSheet: ParagraphSheet = {
        id: `sheet_${Date.now()}`,
        paragraphNumber: nextNum,
        content: '',
        wordCount: 0,
        charCount: 0,
        backspaceCount: 0,
        elapsedSeconds: 0,
        promptGuidance: `Paragraph ${nextNum}: Type your next paragraph here without backspace...`,
        isCompleted: false,
      };

      return [...updated, newSheet];
    });

    setActiveSheetIndex(paragraphSheets.length);
    soundEngine.playKeypress('mechanical', 0.6);

    setTimeout(() => {
      textareaRef.current?.focus();
    }, 50);
  };

  // Load a structured multi-paragraph exercise suite
  const handleLoadExerciseSuite = (suite: typeof PARAGRAPH_EXERCISE_SUITES[0]) => {
    const newSheets: ParagraphSheet[] = suite.paragraphs.map((p, idx) => ({
      id: `suite_${Date.now()}_${idx}`,
      paragraphNumber: idx + 1,
      content: '',
      wordCount: 0,
      charCount: 0,
      backspaceCount: 0,
      elapsedSeconds: 0,
      promptGuidance: p.prompt,
      isCompleted: false,
    }));

    setParagraphSheets(newSheets);
    setActiveSheetIndex(0);
    setActiveTab('notepad');
    setNotepadMode('paragraph-sheets');
    setTimeout(() => textareaRef.current?.focus(), 50);
  };

  // Delete a paragraph sheet
  const handleDeleteSheet = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (paragraphSheets.length <= 1) {
      // Clear if only 1
      handleTextChange('');
      return;
    }
    if (window.confirm(`Delete Paragraph ${idx + 1} notepad sheet?`)) {
      const nextSheets = paragraphSheets
        .filter((_, i) => i !== idx)
        .map((s, newIdx) => ({
          ...s,
          paragraphNumber: newIdx + 1,
        }));
      setParagraphSheets(nextSheets);
      setActiveSheetIndex(Math.max(0, Math.min(activeSheetIndex, nextSheets.length - 1)));
    }
  };

  // Copy compiled text
  const handleCopyCompiled = async () => {
    const textToCopy = notepadMode === 'paragraph-sheets' ? compiledText : continuousContent;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  // Download compiled text as .txt
  const handleDownloadTxt = () => {
    const textToDownload = notepadMode === 'paragraph-sheets' ? compiledText : continuousContent;
    const blob = new Blob([textToDownload], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `futuretrack_notepad_document_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleClearAll = () => {
    if (window.confirm('Clear all paragraph notepads and restart?')) {
      setParagraphSheets([
        {
          id: `sheet_${Date.now()}`,
          paragraphNumber: 1,
          content: '',
          wordCount: 0,
          charCount: 0,
          backspaceCount: 0,
          elapsedSeconds: 0,
          promptGuidance: 'Paragraph 1: Start your opening paragraph...',
          isCompleted: false,
        },
      ]);
      setActiveSheetIndex(0);
      setContinuousContent('');
      setTotalBackspaceAttempts(0);
      setElapsedSessionSeconds(0);
      setIsActiveTimer(false);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const getThemeClass = () => {
    switch (notepadTheme) {
      case 'paper':
        return 'bg-amber-50/40 text-slate-900 border-amber-200/80 shadow-inner';
      case 'warm':
        return 'bg-[#fcf8f2] text-amber-950 border-amber-300 shadow-inner';
      case 'dark':
        return 'bg-slate-950 text-slate-100 border-slate-800 shadow-inner';
      default:
        return 'bg-white text-slate-900 border-slate-200 shadow-inner';
    }
  };

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'large':
        return 'text-lg leading-relaxed';
      case 'xlarge':
        return 'text-xl leading-loose';
      default:
        return 'text-base leading-normal';
    }
  };

  const getFontFamilyClass = () => {
    switch (fontFamily) {
      case 'mono':
        return 'font-mono';
      case 'serif':
        return 'font-serif';
      default:
        return 'font-sans';
    }
  };

  return (
    <div
      ref={containerRef}
      className={`max-w-6xl mx-auto px-4 py-8 ${
        isFullscreen ? 'fixed inset-0 z-50 bg-slate-900 p-6 overflow-y-auto' : ''
      }`}
    >
      {/* Top Banner Header */}
      <div className="bg-white rounded-3xl p-6 shadow-xl border border-slate-200 mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs uppercase font-bold tracking-wider text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
              Zero-Backspace Writing Studio
            </span>
            <span className="text-xs text-slate-400 font-medium">Always New Notepad for Each Paragraph</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading flex items-center gap-2">
            <FileEdit className="w-7 h-7 text-blue-600" />
            Notepad Without Backspace
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Write one paragraph per notepad sheet. When a paragraph is finished, open a fresh notepad for the next paragraph!
          </p>
        </div>

        {/* Global Aggregate Metrics */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-xl text-center">
            <div className="text-[10px] uppercase font-bold text-slate-400">Total Words</div>
            <div className="text-lg font-black font-mono text-slate-900">{totalWords}</div>
          </div>

          <div className="bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-xl text-center">
            <div className="text-[10px] uppercase font-bold text-slate-400">Paragraphs</div>
            <div className="text-lg font-black font-mono text-blue-700">
              {completedParagraphsCount} / {totalParagraphsCount}
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 px-3.5 py-2 rounded-xl text-center">
            <div className="text-[10px] uppercase font-bold text-blue-600">Speed</div>
            <div className="text-lg font-black font-mono text-blue-700">
              {calculatedWpm} <span className="text-xs font-normal">WPM</span>
            </div>
          </div>

          <div
            className={`border px-3.5 py-2 rounded-xl text-center transition-colors ${
              totalBackspaceAttempts > 0
                ? 'bg-rose-50 border-rose-200 text-rose-700'
                : 'bg-slate-50 border-slate-200 text-slate-900'
            }`}
          >
            <div className="text-[10px] uppercase font-bold text-rose-600">Blocked</div>
            <div className="text-lg font-black font-mono text-rose-600">{totalBackspaceAttempts}</div>
          </div>

          <div className="bg-slate-900 text-white px-3.5 py-2 rounded-xl text-center shadow-inner">
            <div className="text-[10px] uppercase font-bold text-slate-400">Session</div>
            <div className="text-lg font-black font-mono text-emerald-400">
              {formatTime(elapsedSessionSeconds)}
            </div>
          </div>
        </div>
      </div>

      {/* Mode & View Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 no-print">
        {/* Paragraph Sheets Mode Switcher */}
        <div className="inline-flex rounded-xl p-1 bg-slate-200/80 border border-slate-300 text-xs font-bold">
          <button
            onClick={() => {
              setNotepadMode('paragraph-sheets');
              setActiveTab('notepad');
            }}
            className={`px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              notepadMode === 'paragraph-sheets'
                ? 'bg-white text-blue-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-blue-600" />
            Always New Notepad Per Paragraph
          </button>
          <button
            onClick={() => setNotepadMode('continuous')}
            className={`px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition ${
              notepadMode === 'continuous'
                ? 'bg-white text-blue-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-slate-500" />
            Continuous Single Page
          </button>
        </div>

        {/* View mode in paragraph-sheets: Edit Active Sheet vs View Full Compiled Document */}
        {notepadMode === 'paragraph-sheets' && (
          <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('notepad')}
              className={`px-3 py-1.5 rounded-lg transition ${
                activeTab === 'notepad' ? 'bg-white shadow text-slate-900 font-bold' : 'text-slate-600'
              }`}
            >
              Active Paragraph Sheet
            </button>
            <button
              onClick={() => setActiveTab('compiled')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'compiled' ? 'bg-white shadow text-blue-700 font-bold' : 'text-slate-600'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              Compiled Document ({totalWords} words)
            </button>
          </div>
        )}
      </div>

      {/* Paragraph Sheets Tab Strip (Always New Notepad per Paragraph) */}
      {notepadMode === 'paragraph-sheets' && activeTab === 'notepad' && (
        <div className="bg-white rounded-2xl p-2.5 border border-slate-200 shadow-xs mb-4 flex items-center gap-2 overflow-x-auto no-print">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 pl-2 shrink-0 flex items-center gap-1">
            <ListOrdered className="w-3.5 h-3.5" />
            Sheets:
          </span>

          <div className="flex items-center gap-1.5 flex-1 overflow-x-auto py-0.5">
            {paragraphSheets.map((sheet, index) => {
              const isActive = index === activeSheetIndex;
              const hasText = sheet.wordCount > 0;
              return (
                <button
                  key={sheet.id}
                  onClick={() => {
                    setActiveSheetIndex(index);
                    setTimeout(() => textareaRef.current?.focus(), 50);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 border ${
                    isActive
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                      : hasText
                      ? 'bg-blue-50 text-blue-900 border-blue-200 hover:bg-blue-100'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>Paragraph {sheet.paragraphNumber}</span>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.2 rounded-md ${
                      isActive ? 'bg-blue-700 text-white' : 'bg-black/5 text-slate-600'
                    }`}
                  >
                    {sheet.wordCount}w
                  </span>
                  {paragraphSheets.length > 1 && (
                    <span
                      onClick={(e) => handleDeleteSheet(index, e)}
                      className="ml-0.5 text-slate-400 hover:text-rose-500 rounded p-0.5"
                      title="Delete Sheet"
                    >
                      ×
                    </span>
                  )}
                </button>
              );
            })}

            {/* "+ New Paragraph Notepad" Button */}
            <button
              onClick={handleCreateNextParagraphNotepad}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flex items-center gap-1.5 shrink-0 cursor-pointer"
              title="Add a fresh new notepad for the next paragraph"
            >
              <Plus className="w-3.5 h-3.5" />
              + New Paragraph Notepad
            </button>
          </div>
        </div>
      )}

      {/* Warning Toast */}
      {showWarning && (
        <div className="mb-4 p-4 bg-rose-600 text-white rounded-2xl shadow-xl flex items-center justify-between animate-bounce border border-rose-700 no-print">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-800/80 flex items-center justify-center font-bold text-lg">
              ⚠
            </div>
            <div>
              <div className="font-extrabold text-sm uppercase tracking-wide">
                Backspace Disabled in this Notepad!
              </div>
              <div className="text-xs text-rose-100">
                You cannot delete previously typed characters. Maintain your cadence and continue typing forward.
              </div>
            </div>
          </div>
          <div className="bg-rose-900/90 px-3 py-1 rounded-lg text-xs font-mono font-bold">
            Blocked keystroke #{totalBackspaceAttempts}
          </div>
        </div>
      )}

      {/* Editor Controls Toolbar */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs mb-3 flex flex-wrap items-center justify-between gap-3 text-xs no-print">
        {/* Font Family & Sizing */}
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-500 uppercase">Font:</span>
          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50">
            <button
              onClick={() => setFontFamily('mono')}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition ${
                fontFamily === 'mono'
                  ? 'bg-white shadow text-blue-700 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mono
            </button>
            <button
              onClick={() => setFontFamily('sans')}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition ${
                fontFamily === 'sans'
                  ? 'bg-white shadow text-blue-700 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sans
            </button>
            <button
              onClick={() => setFontFamily('serif')}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition ${
                fontFamily === 'serif'
                  ? 'bg-white shadow text-blue-700 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Serif
            </button>
          </div>

          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 ml-1">
            <button
              onClick={() => setFontSize('normal')}
              className={`px-2 py-1 rounded-md text-xs transition ${
                fontSize === 'normal' ? 'bg-white shadow font-bold text-blue-700' : 'text-slate-600'
              }`}
            >
              A
            </button>
            <button
              onClick={() => setFontSize('large')}
              className={`px-2 py-1 rounded-md text-sm transition ${
                fontSize === 'large' ? 'bg-white shadow font-bold text-blue-700' : 'text-slate-600'
              }`}
            >
              A+
            </button>
          </div>

          {/* Theme */}
          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 ml-1">
            <button
              onClick={() => setNotepadTheme('paper')}
              className={`px-2 py-1 rounded-md text-xs transition ${
                notepadTheme === 'paper' ? 'bg-amber-100 font-bold text-amber-900 shadow' : 'text-slate-600'
              }`}
              title="Lined Notepad Paper"
            >
              Paper
            </button>
            <button
              onClick={() => setNotepadTheme('clean')}
              className={`px-2 py-1 rounded-md text-xs transition ${
                notepadTheme === 'clean' ? 'bg-white font-bold text-slate-900 shadow' : 'text-slate-600'
              }`}
              title="Clean White"
            >
              Clean
            </button>
            <button
              onClick={() => setNotepadTheme('warm')}
              className={`px-2 py-1 rounded-md text-xs transition ${
                notepadTheme === 'warm' ? 'bg-[#f5ecdd] font-bold text-amber-950 shadow' : 'text-slate-600'
              }`}
              title="Warm Sepia"
            >
              Sepia
            </button>
            <button
              onClick={() => setNotepadTheme('dark')}
              className={`px-2 py-1 rounded-md text-xs transition ${
                notepadTheme === 'dark' ? 'bg-slate-800 font-bold text-white shadow' : 'text-slate-600'
              }`}
              title="Night Focus"
            >
              Night
            </button>
          </div>

          {/* Mechanical Switch Sound Toggle */}
          <button
            onClick={() => {
              const next: SoundEffectType =
                soundType === 'mechanical'
                  ? 'thock'
                  : soundType === 'thock'
                  ? 'typewriter'
                  : soundType === 'typewriter'
                  ? 'silent'
                  : 'mechanical';
              setSoundType(next);
              soundEngine.playKeypress(next, 0.5);
            }}
            className="px-2.5 py-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium flex items-center gap-1.5 transition ml-1"
            title="Switch mechanical switch sound"
          >
            {soundType === 'silent' ? (
              <VolumeX className="w-3.5 h-3.5 text-slate-400" />
            ) : (
              <Volume2 className="w-3.5 h-3.5 text-blue-600" />
            )}
            <span className="capitalize">{soundType}</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsActiveTimer((prev) => !prev)}
            className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition ${
              isActiveTimer
                ? 'bg-amber-100 hover:bg-amber-200 text-amber-900'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
            }`}
          >
            {isActiveTimer ? (
              'Pause Timer'
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" /> Start Timer
              </>
            )}
          </button>

          <button
            onClick={handleCopyCompiled}
            className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold flex items-center gap-1.5 transition"
            title="Copy compiled text"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-slate-500" />
            )}
            {copied ? 'Copied' : 'Copy'}
          </button>

          <button
            onClick={handleDownloadTxt}
            className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold flex items-center gap-1.5 transition"
            title="Download text file (.txt)"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Download
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold flex items-center gap-1.5 transition"
            title="Print transcript"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            Print
          </button>

          <button
            onClick={handleClearAll}
            className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition"
            title="Clear all notepads"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 transition"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Zen Mode'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Notepad Body: Active Sheet View */}
      {activeTab === 'notepad' && (
        <div className={`rounded-3xl border-2 p-6 sm:p-8 transition-all relative ${getThemeClass()}`}>
          {/* Visual Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-4 mb-4 border-current/15 text-xs gap-2">
            <div className="flex items-center gap-3">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-current/20 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-current/20 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-current/20 inline-block"></span>
              </div>
              <span className="font-bold tracking-wider uppercase opacity-75">
                {notepadMode === 'paragraph-sheets'
                  ? `NOTEPAD SHEET #${currentSheet?.paragraphNumber || 1} · PARAGRAPH ${currentSheet?.paragraphNumber || 1}`
                  : 'CONTINUOUS ZERO-BACKSPACE NOTEPAD'}
              </span>
            </div>

            <div className="flex items-center gap-3 opacity-75 font-mono text-[11px]">
              <span>
                Paragraph Words: <strong>{notepadMode === 'paragraph-sheets' ? currentSheet?.wordCount : continuousContent.split(/\s+/).filter(Boolean).length}</strong>
              </span>
              <span>·</span>
              <span>
                Characters: <strong>{notepadMode === 'paragraph-sheets' ? currentSheet?.charCount : continuousContent.length}</strong>
              </span>
            </div>
          </div>

          {/* Optional Prompt Guidance for this paragraph */}
          {notepadMode === 'paragraph-sheets' && currentSheet?.promptGuidance && (
            <div className="mb-3 p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl text-xs opacity-90">
              <span className="font-bold text-blue-600 uppercase tracking-wide mr-1.5">Prompt:</span>
              <span>{currentSheet.promptGuidance}</span>
            </div>
          )}

          {/* Dedicated Textarea for this Paragraph */}
          <textarea
            ref={textareaRef}
            value={notepadMode === 'paragraph-sheets' ? currentSheet?.content || '' : continuousContent}
            onChange={(e) => handleTextChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              notepadMode === 'paragraph-sheets'
                ? `Type Paragraph ${currentSheet?.paragraphNumber || 1} here...\n\nRemember: Backspace & Delete are disabled. When you finish this paragraph, click "+ New Paragraph Notepad" (or press Ctrl + Enter) to open a fresh notepad for the next paragraph!`
                : 'Start typing your continuous essay or transcript here...\n\nRemember: Backspace & Delete are completely disabled. Commit every keystroke forward with steady focus.'
            }
            rows={isFullscreen ? 24 : 14}
            spellCheck={false}
            className={`w-full bg-transparent resize-y outline-none transition-colors border-none p-0 ${getFontFamilyClass()} ${getFontSizeClass()}`}
            style={{
              lineHeight: notepadTheme === 'paper' ? '2.2rem' : undefined,
              backgroundImage:
                notepadTheme === 'paper'
                  ? 'repeating-linear-gradient(transparent, transparent 2.1rem, rgba(0, 0, 0, 0.06) 2.1rem, rgba(0, 0, 0, 0.06) 2.2rem)'
                  : undefined,
            }}
          />

          {/* Bottom Actions Bar */}
          <div className="mt-4 pt-3 border-t border-current/10 flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
            <div className="flex items-center gap-1.5 opacity-75">
              <ShieldAlert className="w-4 h-4 text-rose-500 shrink-0" />
              <span>Anti-Correction Active: Backspace & Delete produce zero deletion.</span>
            </div>

            {/* Paragraph Completion Button */}
            {notepadMode === 'paragraph-sheets' && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCreateNextParagraphNotepad}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
                >
                  <span>Finish & Open New Paragraph Notepad</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Compiled Multi-Paragraph Document View */}
      {activeTab === 'compiled' && notepadMode === 'paragraph-sheets' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 pb-4 mb-6 gap-2">
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-heading">
                Compiled Document (All Paragraphs)
              </h3>
              <p className="text-xs text-slate-500">
                All individual paragraph notepads assembled into a unified document.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyCompiled}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy All'}
              </button>
              <button
                onClick={handleDownloadTxt}
                className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                Download Document
              </button>
            </div>
          </div>

          {compiledText ? (
            <div className="space-y-6 font-serif text-base sm:text-lg leading-relaxed text-slate-800">
              {paragraphSheets.map((s) => (
                <div key={s.id} className="relative pl-6 border-l-2 border-blue-200">
                  <span className="absolute -left-3 top-0 w-6 h-6 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold flex items-center justify-center font-mono">
                    {s.paragraphNumber}
                  </span>
                  <p className="whitespace-pre-wrap">{s.content || <span className="italic text-slate-400">[Empty paragraph sheet]</span>}</p>
                  <div className="text-[10px] text-slate-400 font-mono mt-1">
                    Paragraph {s.paragraphNumber} · {s.wordCount} words · {s.charCount} chars
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 text-sm">
              No paragraphs typed yet. Switch back to the Active Paragraph Sheet and start typing!
            </div>
          )}
        </div>
      )}

      {/* Multi-Paragraph Exercise Suites & Templates */}
      <div className="mt-8 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs no-print">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h3 className="text-base font-bold text-slate-900 font-heading">
              Structured Multi-Paragraph Writing Suites
            </h3>
          </div>
          <span className="text-xs text-slate-500 hidden sm:inline">
            Loads individual sequential notepads for each paragraph
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {PARAGRAPH_EXERCISE_SUITES.map((suite, sIdx) => (
            <div
              key={sIdx}
              className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 inline-block mb-2">
                  {suite.category} · {suite.paragraphs.length} Paragraph Notepads
                </span>
                <h4 className="text-sm font-bold text-slate-900 mb-1.5">{suite.title}</h4>
                <ul className="text-xs text-slate-600 space-y-1 mb-4 list-disc pl-4">
                  {suite.paragraphs.map((p, pIdx) => (
                    <li key={pIdx} className="line-clamp-1">
                      {p.prompt}
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => handleLoadExerciseSuite(suite)}
                className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-blue-50 border border-slate-300 hover:border-blue-400 text-slate-800 hover:text-blue-700 font-bold text-xs shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Load This Multi-Paragraph Suite</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
